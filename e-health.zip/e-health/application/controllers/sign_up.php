<?php session_start();
require_once('dbconnection.php');

//Code for Registration 
if(isset($_POST['sign_up']))
{
	$username=$_POST['username'];
	
	$email=$_POST['email'];
	$password=$_POST['password'];
	
	$enc_password=$password;

	$msg=mysqli_query($con,"insert into users(username,email,password) values('$username','$email','$enc_password')");

if($msg)
{
	echo "<script>alert('Register successfully');</script>";
}
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
  
</head>
<!--internal CSS -->
<style>

input[type=submit] {
  width: 10%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

body {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}

.header {
  background-color: #F1F1F1;
  text-align: center;
  padding: 20px;
}

</style>

    <body>

	
   <!--Sign in form -->
        <header>
       <h2>Welcome </h2>
        </header>
	
        <form method="POST" action="">

            <h3>Please Fill in the fields below to sign up:</h3>

            <!-- Username -->
            <label for="username"> Username: </label><br>
            <input type="text" name="username" maxlength="64" required >
            <br>

            <!-- Email -->
            <label for="email">Email: </label><br>
            <input type="email" name="email" id="email" maxlength="75" required>
            <br>

             <!-- Password -->
            <label for="password"> Password: </label><br>
            <input type="password" id="password" name="password" maxlength="64" required >
            <br>


            <!-- Sign up -->
            <input type="submit" name="sign_up" value="Sign up">

            <br><br>

           
            <p>Already a member? <a id="sign_in" href="/e-health/index.php/login">Sign in</a></p>

        </form> 

    </body>

</html>
