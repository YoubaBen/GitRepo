<!DOCTYPE html>
<html>
<head>
<title>Users</title>
<style>
table {
border-collapse: collapse;
width: 100%;
color: #588c7e;
font-family: monospace;
font-size: 25px;
text-align: left;
}
th {
background-color: #588c7e;
color: white;
}
tr:nth-child(even) {background-color: #f2f2f2}
</style>
</head>
<body>
<table>
<tr>

<th>Username</th>
<th>Password</th>
</tr>

<?php
//  Make a database connection so that we can fetch data from a database.
$conn = mysqli_connect("localhost", "root", "", "ehealth");
// Check connection
if ($conn->connect_error) {
// SQL query to select data from a database.
die("Connection failed: " . $conn->connect_error);
}

//Execute a SELECT query and store the result in a $result
$sql = "SELECT  username, password FROM users";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo  "</td><td>" . $row["username"] . "</td><td>"
. $row["password"]. "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();

//  If that result contains more than 0 rows then display that data in an HTML table
// If the result contains 0 rows then give a message �0 results� and close a database connection.
?>
</table>
</body>
</html>

