<!DOCTYPE html>
<html>
<head>
<title>Users Info</title>
<style>
table {
border-collapse: collapse;
width: 100%;
color: #588c7e;
font-family: monospace;
font-size: 25px;
text-align: left;
}
th {
background-color: #588c7e;
color: white;
}
tr:nth-child(even) {background-color: #f2f2f2}
</style>
</head>
<body>
<table>
<tr>
<th>Title</th>
<th>FirstName</th>
<th>Surname</th>
<th>Date of birth</th>
<th>Marital Status</th>
<th>Adresse</th>
<th>Postcode</th>
<th>Mobile</th>
<th>Occupation</th>
<th>Gender</th>
<th>Height</th>
<th>Weight</th>
</tr>

<?php
//  Make a database connection so that we can fetch data from a database.
$conn = mysqli_connect("localhost", "root", "", "ehealth");
// Check connection
if ($conn->connect_error) {
// SQL query to select data from a database.
die("Connection failed: " . $conn->connect_error);
}

//Execute a SELECT query and store the result in a $result
$sql = "SELECT  title, firstname , surname , dob , marital_status , address , postcode ,  mobile , occupation , gender , height , weight  FROM users";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo  "</td><td>" . $row["title"] . "</td><td>"
. $row["firstname"]. "</td><td>" . $row["surname"] ."</td><td>" . $row["dob"]."</td><td>" . $row["marital_status"]."</td><td>" . $row["address"]
."</td><td>" . $row["postcode"]."</td><td>" . $row["mobile"]."</td><td>" . $row["mobile"]."</td><td>" . $row["occupation"]."</td><td>" . $row["gender"]."</td><td>" . $row["height"]
."</td><td>" . $row["weight"]  ."</td></tr>"    ;
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();

//  If that result contains more than 0 rows then display that data in an HTML table
// If the result contains 0 rows then give a message �0 results� and close a database connection.
?>
</table>
</body>
</html>