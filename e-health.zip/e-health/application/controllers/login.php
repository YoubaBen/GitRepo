<?php session_start();
require_once('dbconnection.php');


// Code for login 
if(isset($_POST['login']))
{
$password=$_POST['password'];
$dec_password=$password;
$username=$_POST['username'];
$ret= mysqli_query($con,"SELECT * FROM users WHERE username='$username' and password='$dec_password'");
$num=mysqli_fetch_array($ret);
if($num>0)
{
// checking that username and pass match with the ones in database
$extra="welcome";
$_SESSION['login']=$_POST['username'];
$_SESSION['username'] = $username; 

$host=$_SERVER['HTTP_HOST'];
$uri=rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
header("location:http://$host$uri/$extra");
exit();
}
else
{
echo "<script>alert('Invalid username or password');</script>";
$extra="login";
$host  = $_SERVER['HTTP_HOST'];
$uri  = rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
//header("location:http://$host$uri/$extra");
exit();
}
}



?>
<!DOCTYPE html>
<html>
<head>
<title>Login </title>

<!--internal CSS -->
	<style>

input[type=submit] {
  width: 10%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

body {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}

.header {
  background-color: #F1F1F1;
  text-align: center;
  padding: 20px;
}

</style>

<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<div class="main">
		<h1>Login System</h1>
	 
			  	 
			
							<form name="login" action="" method="post">
							<h3> Please enter your Username and Password: </h3>

							      <label for="username"> Username: </label>
							  	<input type="text" class="text" name="username" value=""  >
								<br><br>
								 <label for="password"> Password: </label>
						         <input type="password" value="" name="password" >
						      <div class="p-container">
								
									<div class="submit two">
									<input type="submit" name="login" value="LOG IN" >
									</div>
									<div class="clear"> </div>
								<br><br>
								  <p>New member ?  <a id="sign_up" href="/e-health/index.php/sign_up">Sign in here </a></p>


							</form>
					
								
				     
		                  </div>
</div>
	    

</body>
</html>
