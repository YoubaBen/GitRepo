
<?php session_start();
require_once('dbconnection.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">


	
	<title><?php echo $appName;?></title>
	<!--internal CSS -->
	<style>

input[type=submit] {
  width: 10%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

body {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}

.header {
  background-color: #F1F1F1;
  text-align: center;
  padding: 20px;
}

</style>


</head>

<body>





<div id="container">
	<center><h1><?php echo "Welcome to the " .$appName. " Portal";?></h1></center>
    <p>Welcome <strong><?php echo $_SESSION['username']; ?></strong></p>

   <p id="description"> In order to register as a new patient at the Practice you need to complete this form. Please complete all of the
relevant questions to the best of your ability, if you can't answer a certain question , please fill with "none" .Thank you ! </p> 
</div>

<header>
    <h2>Your details</h2>
    
  

<head>
<style>
.error {color: #FF0000;}
</style>
</head>
<body>  

<?php
// define variables and set to empty values
$titleErr = $nameErr = $surnameErr  = $dobErr = $msErr =$adresseErr = $postcodeErr = $phonenumberErr = $phonenumberErr2 = $emailErr = $genderErr = "";
$title =  $name = $name2 = $surname = $dob = $ms = $adresse = $postcode = $phonenumber = $phonenumber2 = $email =$yn =$yn1 =$yn2 =$yn3=$yn4 =$yn4 =$yn5 =$yn6 =  $occupation = $gender 
 =$height = $weight = $medication = $allergies =  $relation=  $comment =  "";



  


if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["name"])) {
    $nameErr = "Name is required";
  } else {
    $name = test_input($_POST["name"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z-' ]*$/",$name)) {
      $nameErr = "Only letters and white space allowed";
    }
  }
  

  if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["surname"])) {
    $surnameErr = "Surname is required";
  } else {
    $surname = test_input($_POST["surname"]);
    // check if surname only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z-' ]*$/",$surname)) {
      $surnameErr = "Only letters and white space allowed";
    }
  }




  
  // check  that title is not empty
  if (empty($_POST["title"])) {
    $titleErr = "Title is required";
  } else {
    $title = test_input($_POST["title"]);
  }
  

  // check  that genderis not empty

  if (empty($_POST["gender"])) {
    $genderErr = "Required";
  } else {
    $gender = test_input($_POST["gender"]);

  } 

  

  // adresse
  if (empty($_POST["adresse"])) {
    $adresseErr = "Adresse is required";
  } else {
    $adresse = test_input($_POST["adresse"]);
  }
  // postcode

    if (empty($_POST["postcode"])) {
    $postcodeErr = "Postcode is required";
  } else {
    $postcode = test_input($_POST["postcode"]);
  }


  // Marital status
    if (empty($_POST["ms"])) {
    $msErr = "Marital status is required";
  } else {
    $ms = test_input($_POST["ms"]);

  } 

  // date of birth
  if (empty($_POST["dob"])) {
    $dobErr = "Date of birth  is required";
  } else {
    $dob = test_input($_POST["dob"]);
  }
} 

}


function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}



?>

<!--Questionnaire -->

<!--Assigning the values so the answers get stored in database , also makes sure that the required fields are not empty (form validation-->


<p><span class="error">* Required fields</span></p>
<form method="post" action="" >  

Title :
  <input type="radio" name="title" <?php if (isset($title) && $title=="Mr") echo "checked";?> value="Mr">Mr
  <input type="radio" name="title" <?php if (isset($title) && $title=="Ms") echo "checked";?> value="Ms">Ms
  <input type="radio" name="title" <?php if (isset($title) && $title=="Dc") echo "checked";?> value="Other">Other  
  <span class="error">* <?php echo $titleErr;?></span>
  <br><br>





  Name: <input type="text" name="firstname" value="<?php echo $name;?>">
  <span class="error">* <?php echo $nameErr;?></span>
  <br><br>


  Surname: <input type="text" name="surname" value="<?php echo $surname;?>">
  <span class="error">* <?php echo $surnameErr;?></span>
  <br><br>

  Date of Birth : <input  type="date" name= "dob" value= "<?php echo $dob;?>">
    <span class="error">* <?php echo $dobErr;?></span>
  <br><br>

 Marital Status  :
  <input type="radio" name="ms" <?php if (isset($ms) && $ms=="married") echo "checked";?> value="Married">Married
  <input type="radio" name="ms" <?php if (isset($ms) && $ms=="single") echo "checked";?> value="Single">Single
  <input type="radio" name="ms" <?php if (isset($ms) && $ms=="other") echo "checked";?> value="Other">Other  
  <span class="error">* <?php echo $msErr;?></span>
  <br><br>

   Adresse : <input type="text" name="adresse" value="<?php echo $adresse;?>">
  <span class="error">* <?php echo $adresseErr;?></span>
    <br><br>
  Post code : <input type="text" name="postcode" value="<?php echo $postcode;?>">
  <span class="error">* <?php echo $postcodeErr;?></span>
  
  <br><br>

  Phone number :  <input type="tel" id="tel" name="phonenumber"   value="<?php echo $phonenumber;?>" required >
   <span class="error">* </span>
  



  If you have supplied your mobile number, please confirm if you would be happy to receive contact via SMS message :   
  <input type="radio" name="yn" <?php if (isset($yn) && $yn=="yes") echo "checked";?> value="Yes">Yes
  <input type="radio" name="yn" <?php if (isset($yn) && $yn=="no") echo "checked";?> value="No">No
  <br><br>

  
  <label for="occupation">Occupation:</label>
  <input type="text" id="occupation" name="occupation"   value="<?php echo $occupation;?>" required >
  <span class="error">*</span>
  

   <br><br>
  E-mail: <input type="text" name="email" value="<?php echo $email;?>">
  

If you have supplied your email address, please confirm if you would be happy to receive email
communications from us : 
    <input type="radio" name="yn1" <?php if (isset($yn1) && $yn1=="yes") echo "checked";?> value="Yes">Yes
    <input type="radio" name="yn1" <?php if (isset($yn1) && $yn1=="no") echo "checked";?> value="No">No



  <br><br>

 


  Gender:
  <input type="radio" name="gender" <?php if (isset($gender) && $gender=="female") echo "checked";?> value="female">Female
  <input type="radio" name="gender" <?php if (isset($gender) && $gender=="male") echo "checked";?> value="male">Male
  <input type="radio" name="gender" <?php if (isset($gender) && $gender=="other") echo "checked";?> value="other">Other  
  <span class="error">* <?php echo $genderErr;?></span>
  <br><br>


 
  <label for="weight">Weight:</label>
  <input type="text" id="weight" name="weight" placeholder="In KG"  value="<?php echo $weight;?>" required >
  <span class="error">*</span>
 
  <br><br>

  <label for="height">Height:</label>
  <input type="text" id="height" name="height"  placeholder="In CM" value="<?php echo $height;?>" required >
   <span class="error">* </span>
 

  <br><br>

   <h2>Next of kin :</h2>
    
  Name: <input type="text" name="name2" value="<?php echo $name2;?>" required >
  <span class="error">* <?php echo $nameErr;?></span>

  <br><br>

   <label for="relation">Relationship:</label>
  <input type="text" id="relation" name="relation"   value="<?php echo $relation;?>" required >
   <span class="error">* </span>
   <br><br>


    <label for="tel">Telephone:</label>
  <input type="tel" id="tel2" name="phonenumber2"   value="<?php echo $phonenumber2;?>" required >
   <span class="error">*<?php echo $phonenumberErr;?></span> </span>
   <br><br>

    <h2>Smoking Status :</h2>

  
  <input type="radio" name="smoke" <?php if (isset($smoke) && $smoke=="smoker") echo "checked";?> value="smoker">Smoker
  <input type="radio" name="smoke" <?php if (isset($smoke) && $smoke=="ex-smoker") echo "checked";?> value="ex-smoker">Ex-Smoker
  <input type="radio" name="smoke" <?php if (isset($smoke) && $smoke=="neversmoked") echo "checked";?> value="neversmoked">Never Smoked 
  <span class="error">* <?php echo $genderErr;?></span>
  <br><br>

  If you are a current smoker , what do you smoke ? :
  <input type="radio" name="type" <?php if (isset($type) && $type=="Cigarettes") echo "checked";?> value="Cigarettes">Cigarettes/Cigars
  <input type="radio" name="type" <?php if (isset($type) && $type=="E-Cigarettes") echo "checked";?> value="E-Cigarettes">E-Cigarettes
  <input type="radio" name="type" <?php if (isset($type) && $type=="Pipe") echo "checked";?> value="Pipe">Pipe
   <br><br>
  <label for="smkr">  If you are a smoker , how long have you been smoking (years) ? </label>
  <input type="text" id="smkr" name="smkr">
  <br><br>


   <h2>Medication :</h2>

   
Are you currently taking any medication: 
  <input type="radio" name="medication" <?php if (isset($medication) && $medication=="yes") echo "checked";?> value="Yes">Yes
  <input type="radio" name="medication" <?php if (isset($medication) && $medication=="no") echo "checked";?> value="No">No
   <span class="error">* <?php echo $genderErr;?></span>

   <br><br>
  
If you answered yes to the above, please list any prescribed or non-prescribed medication : 
 <br><br>
<label for="medname">Medication Name:</label><br>
<input type="text" id="medname" name="medname"><br>

<label for="dosage">Dosage:</label><br>
<input type="text" id="Dosage" name="Dosage"><br>

<label for="howoften">How often :</label><br>
<input type="text" id="howoften" name="howoften"><br>

<br><br>

<h2>Alcohol use audit :</h2>
 Do you drink Alcohol ? : 
  <input type="radio" name="yn2" <?php if (isset($yn2) && $yn2=="yes") echo "checked";?> value="Yes">Yes
  <input type="radio" name="yn2" <?php if (isset($yn2) && $yn2=="no") echo "checked";?> value="No">No 
  <br>

   <label for="alcohol">  If yes, how many units a week?  ? </label>
  <input type="text" id="alcohol" name="alcohol">
  <br><br>



<br><br>


<h2>Family Medical history  :</h2>


Do any of your close family (grandparents, parents, brothers, sisters) suffer from or have had, any of the
following conditions : 
  <br><br>
  Heart disease : 
  <input type="radio" name="yn3" <?php if (isset($yn3) && $yn3=="yes") echo "checked";?> value="Yes">Yes
  <input type="radio" name="yn3" <?php if (isset($yn3) && $yn3=="no") echo "checked";?> value="No">No

 
  <label for="fmember">/If yes , which family member ? </label>
<input type="text" id="fmember" name="fmember"><br>
  <br><br>

Cancer : 
  <input type="radio" name="yn4" <?php if (isset($yn4) && $yn4=="yes") echo "checked";?> value="Yes">Yes
  <input type="radio" name="yn4" <?php if (isset($yn4) && $yn4=="no") echo "checked";?> value="No">No

 
  <label for="fmember">/If yes , which family member ? </label>
<input type="text" id="fmember" name="fmember"><br>
  <br><br>

 Stroke : 
  <input type="radio" name="yn5" <?php if (isset($yn5) && $yn5=="yes") echo "checked";?> value="Yes">Yes
  <input type="radio" name="yn5" <?php if (isset($yn5) && $yn5=="no") echo "checked";?> value="No">No

 
  <label for="fmember">/If yes , which family member ? </label>
<input type="text" id="fmember" name="fmember"><br>
  <br><br>
   <label for="other">Other  </label>
<input type="text" id="otherd" name="otherd">

 <label for="fmember">/Which family member ? </label>
<input type="text" id="fmember" name="fmember"><br>

<br><br>

<h2>Allergies:</h2>
Are you allergic to any medicines, substances or foods?
  <input type="radio" name="allergies" <?php if (isset($allergies) && $allergies=="yes") echo "checked";?> value="Yes">Yes
  <input type="radio" name="allergies" <?php if (isset($allergies) && $allergies=="no") echo "checked";?> value="No">No
   <span class="error">* <?php echo $genderErr;?></span>
   <br><br>
   
<label for="alrg"> If yes, please give details: </label>
<input type="text" id="alrg" name="alrg"><br>

   <br><br>
   <h2>Lifestyle:</h2>

 Do you take regular exercise?

  <input type="radio" name="yn6" <?php if (isset($yn6) && $yn6=="yes") echo "checked";?> value="Yes">Yes
  <input type="radio" name="yn6" <?php if (isset($yn6) && $yn6=="no") echo "checked";?> value="No">No
  <br><br>
  <label for="session">How long do you exercise for in one session? :</label>
  <input type="text" id="minutes" name="minutes"  placeholder="In minutes"><br>
  
  <label for="session">How often do you exercise in a typical week?:</label>
  <input type="text" id="days" name="days"  placeholder="In days"><br>
   <br><br>
  



    <input type="submit" name="submit" value="submit">  
</form>



	
	

<?php
if(isset($_POST['submit']))
{
  //Getting the values submitted from the questionnaire   
	$firstname=$_POST['firstname'];
    $dob=$_POST['dob'];
    $phonenumber=$_POST['phonenumber'];
    $occupation=$_POST['occupation'];
    $height=$_POST['height'];
    $weight=$_POST['weight']; 
    $name2=$_POST['name2'];
    $relation =$_POST['relation'];
    $phonenumber2= $_POST['phonenumber2']; 
    $yn=$_POST['yn'];
    $yn1=$_POST['yn1'];
    $smoke=$_POST['smoke'];  
    $type=$_POST['type'];
    $years=$_POST['years'];
    $medication=$_POST['medication'];
    $medname=$_POST['medname'];
    $Dosage=$_POST['Dosage'];   
    $frequency=$_POST['howoften'];
    $alrg=$_POST['alrg'];
    $cancer=$_POST['yn3'];
    $hd=$_POST['yn4'];
    $stroke=$_POST['yn5'];
    $other=$_POST['otherd'];
    $yn6=$_POST['yn6'];
    $minutes=$_POST['minutes'];
    $days=$_POST['days'];

 // inserting the values into the ehealth database
	
 $msg=mysqli_query($con,"insert into users(title,firstname ,surname , dob, marital_status  , address , postcode ,mobile ,  SMS_YN ,email_yn , occupation , gender, height , weight, kin_name , kin_relationship , kin_telephone) values ( '$title' ,
 '$firstname','$surname' , '$dob', '$ms' , '$adresse' , '$postcode' ,'$phonenumber'   ,'$yn' , '$yn1' , '$occupation' , '$gender' , '$height' , '$weight', '$name2' , '$relation' , '$phonenumber2')");

  $msg2=mysqli_query($con,"insert into smoking (smoke_status , smoke_type, years_smoking) values('$smoke' , '$type' , '$years')");

 
  $msg3=mysqli_query($con,"insert into medication (Medication_YN , Medication_1 , medication_frequency_1 , medication_dosage_1) values('$medication' , '$medname' , '$frequency' , '$Dosage' )");
  
  $msg4=mysqli_query($con,"insert into allergies (allergy_details ) values('$alrg' )");

  $msg5=mysqli_query($con,"insert into medical_histroy (has_cancer , has_heart_disease , has_stroke , has_other ) values('$cancer' , '$hd' , '$stroke', '$other' )");

  $msg6=mysqli_query($con,"insert into lifestyle (exercise , exercise_muntes , exercise_days ) values('$yn6' , '$minutes' ,  '$days')");


if($msg)
{
	echo "<script>alert('Information recieved  successfully');</script>";




}
}



?>





</header>


</body>

</html>

